module.exports = function(grunt) {
  grunt.initConfig({
    pkg: grunt.file.readJSON('package.json'),
    clean: {
      main: ['.build']
    },
    transport: {
      options: {
        paths: ['source/jslib'],
        alias: '<%= pkg.config.alias %>'
      },
      alljs: {
        options: {
          idleading: '<%= pkg.config.grunt.jsfolder %>'
        },
        files: [{
          expand: true,
          cwd: 'source/jslib/<%= pkg.config.grunt.jsfolder %>',
          src: '**/*.js',
          dest: '.build/transport/js/<%= pkg.config.grunt.jsfolder %>'
        }]
      }
    },
    concat: {
      alljs: {
        options: {
          include: 'relative',
          paths: ['source/jslib'],
          alias: '<%= alias %>'
        },
        files: [{
          expand: true,
          cwd: '.build/transport/js/<%= pkg.config.grunt.jsfolder %>',
          src: '**/*.js',
          filter: function(filepath) {
            return !/(.*plugins.*\.js)|(.*mod.*\.js)|(-debug\.js)$/.test(filepath);
          },
          dest: '.build/concat/js/<%= pkg.config.grunt.jsfolder %>'
        }]
      }
    },
    uglify: {
      options: {
        banner: '/*!365RRS(http://www.365rrs.com)-<%= grunt.template.today("dd-mm-yyyy") %> */\n'
      },
      alluntils:{
        files: [{
          expand: true,
          cwd: 'pub/untils/<%= pkg.config.grunt.untilsfolder %>',
          src: '**/*.js',
          dest: 'pub/untils/<%= pkg.config.grunt.untilsfolder %>'
        }]
      },
      allplugins:{
        files: [{
          expand: true,
          cwd: 'pub/jslib/plugins/<%= pkg.config.grunt.pluginsfolder %>',
          src: '**/*.js',
          dest: 'pub/jslib/plugins/<%= pkg.config.grunt.pluginsfolder %>'
        }]
      },
      alljs: {
        files: [{
          expand: true,
          cwd: '.build/concat/js/<%= pkg.config.grunt.jsfolder %>',
          src: '**/*.js',
          dest: 'pub/jslib/<%= pkg.config.grunt.jsfolder %>'
        }]
      }
    },
    jshint: {
      files: ['Gruntfile.js','source/jslib/<%= pkg.config.grunt.jsfolder %>/**/*.js','!source/jslib/plugins/**/*.js','!source/untils/**/*.js'],
      options: {
        globals: {
          jQuery: true,
          console: true,
          module: true,
          document: true
        }
      }
    },
    cssmin: {
      options: {
        banner: '/*!365RRS(http://www.365rrs.com)-<%= grunt.template.today("dd-mm-yyyy") %> */\n'
      },
      alluntils:{
        files: [{
          expand: true,
          cwd: 'pub/untils/<%= pkg.config.grunt.untilsfolder %>',
          src: '**/*.css',
          dest: 'pub/untils/<%= pkg.config.grunt.untilsfolder %>'
        }]
      },
      allplugins:{
        files: [{
          expand: true,
          cwd: 'pub/jslib/plugins/<%= pkg.config.grunt.pluginsfolder %>',
          src: '**/*.css',
          dest: 'pub/jslib/plugins/<%= pkg.config.grunt.pluginsfolder %>'
        }]
      },
      allcss: {
        files: [{
          expand: true,
          cwd: 'source/csslib/<%= pkg.config.grunt.cssfolder %>',
          src: ['**/*.css','!mod/*.css'],
          dest: 'pub/csslib/<%= pkg.config.grunt.cssfolder %>'
        }]
      }
    },
    less: {
      allless: {
        files: [{
          expand: true,
          cwd: 'source/csslib',
          src: ['**/*.less','!mod/*.less'],
          dest: 'source/csslib',
          ext: '.css'
        }]
      }
    },
    watch: {
      options: {
        livereload:true
      },
      js: {
        files: ['source/jslib/**/*.js','!source/jslib/plugins/**/*.js','!source/untils/**/*.js'],
        tasks: ['jshint']
      },
      css: {
        files: ['source/csslib/**/*.less'],
        tasks: ['less']
      },
      html: {
        files: ['html/**/*.html']
      }
    },
    copy: {
      alluntils: {
        files: [{
          expand: true,
          cwd: 'source/untils/<%= pkg.config.grunt.untilsfolder %>',
          src: '**/*.*',
          dest: 'pub/untils/<%= pkg.config.grunt.untilsfolder %>'
        }]
      },
      allplugins: {
        files: [{
          expand: true,
          cwd: 'source/jslib/plugins/<%= pkg.config.grunt.pluginsfolder %>',
          src: '**/*.*',
          dest: 'pub/jslib/plugins/<%= pkg.config.grunt.pluginsfolder %>'
        }]
      }
    }
  });
  /*加载任务
  grunt.loadNpmTasks('grunt-contrib-clean');
  grunt.loadNpmTasks('grunt-contrib-copy');
  grunt.loadNpmTasks('grunt-cmd-transport');
  grunt.loadNpmTasks('grunt-cmd-concat');
  grunt.loadNpmTasks('grunt-contrib-uglify');
  grunt.loadNpmTasks('grunt-contrib-jshint');
  grunt.loadNpmTasks('grunt-contrib-less');
  grunt.loadNpmTasks('grunt-contrib-cssmin');
  grunt.loadNpmTasks('grunt-contrib-watch');*/
  /*执行任务*/
  grunt.registerTask('default', function () {
    grunt.log.writeln( '请选择任务名称' );
  });
  grunt.registerTask('build', ['clean', 'transport', 'concat', 'copy', 'uglify', 'cssmin']);
};